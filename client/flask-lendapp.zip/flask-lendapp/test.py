import tensorflow as tf

def load_model(version=6):
    model = tf.keras.models.load_model("models/{}".format(version))
    return model


def predict(model=None, sample={
    "application_type": "Individual",
    "num_tl_120dpd_2m": 0,
    "num_tl_30dpd": 0,
    "num_tl_90g_dpd_24m": 0,
    "num_tl_op_past_12m": 2,
    "pub_rec_bankruptcies": 0,
    "term": "36 months",
    "loan_amnt": 20000,
    "avg_cur_bal": 30030,
    "dti": 14.67,
    "installment": 637.58,
    "purpose": "debt_consolidation",
}):
    if model is None:
        return -1
    input_dict = {name: tf.convert_to_tensor(
        [value]) for name, value in sample.items()}
    predictions = model.predict(input_dict)
    print(predictions)
    return 1

if __name__ == "__main__":
    model = load_model()
    predict(model)