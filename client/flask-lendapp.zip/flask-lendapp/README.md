# LendApp

Aplicación web que permite utilizar la implementación del modelo, soporta versionamiento del modelo.

![Captura 1](capturas/captura1.png)

## Requerimientos

- Python 3.x

## Configuración y ejecución

1. Instalamos las dependencias con `pip install -r requirements.txt``
2. Especificamos el archivo del servidor con `export FLASK_APP=app.py`
3. Iniciamos el servidor con `flask run`
4. Navegamos a `http://localhost:5000/` donde podremos ver el formulario que llenaremos

## Test rápido del modelo

Podemos probar rápidamente el modelo ejecutando el archivo `test.py`. Es necesario tener las dependencias instaladas, este test carga un ejemplo quemado. Los valores cercanos a 0 indican un mal préstamo y valores cercanos a 1 un buen préstamo.
