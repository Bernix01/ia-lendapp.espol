from flask import Flask, render_template, request, jsonify, make_response

import tensorflow as tf

app = Flask(__name__)


def load_model(version=5):
    model = tf.keras.models.load_model("models/{}".format(version))
    return model


def do_predict(model=None, sample={
    "application_type": "",
    "num_tl_120dpd_2m": 0,
    "num_tl_30dpd": 0,
    "num_tl_90g_dpd_24m": 0,
    "num_tl_op_past_12m": 0,
    "pub_rec_bankruptcies": 0,
    "term": "36 months",
    "loan_amnt": 0.0,
    "avg_cur_bal": 0.0,
    "dti": 0.0,
    "installment": 0.0,
    "purpose": "",
}):
    if model is None:
        return -1
    sample["num_tl_120dpd_2m"] = int(sample["num_tl_120dpd_2m"])
    sample["num_tl_30dpd"] = int(sample["num_tl_30dpd"])
    sample["num_tl_90g_dpd_24m"] = float(sample["num_tl_90g_dpd_24m"])
    sample["num_tl_op_past_12m"] = float(sample["num_tl_op_past_12m"])
    sample["pub_rec_bankruptcies"] = float(sample["pub_rec_bankruptcies"])
    sample["loan_amnt"] = float(sample["loan_amnt"])
    sample["avg_cur_bal"] = float(sample["avg_cur_bal"])
    sample["dti"] = float(sample["dti"])
    sample["installment"] = float(sample["installment"])
    input_dict = {name: tf.convert_to_tensor(
        [value]) for name, value in sample.items()}
    predictions = model.predict(input_dict)
    return predictions[0][0]


@app.route('/')
def index():
    return render_template('form.html')


@app.route('/predict', methods=['POST'])
def predict():

    model = load_model()
    result = do_predict(model, request.json)
    result_json = {
        "result": "\nEste prestamo no resultará riesgoso con un {:0.2f}% de probabilidad.\n".format(result*100)
    }
    return make_response(jsonify(result_json), 200)
